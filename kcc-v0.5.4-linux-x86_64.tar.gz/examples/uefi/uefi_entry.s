.section .pe_header, "a"
.align 16

dos_header:
    .ascii "MZ"
    .space 58
    .long pe_header - dos_header       /* e_lfanew */

pe_header:
    .ascii "PE\0\0"
    /* COFF File Header (20 bytes) */
    .word 0x8664                        /* Machine: AMD64 */
    .word 2                             /* NumberOfSections (.text, .reloc) */
    .long 0                             /* TimeDateStamp */
    .long 0                             /* PointerToSymbolTable */
    .long 0                             /* NumberOfSymbols */
    .word opt_header_end - opt_header   /* SizeOfOptionalHeader */
    .word 0x0206                        /* Characteristics: EXECUTABLE | LINE_NUMS_STRIPPED | LARGE_ADDRESS_AWARE */

opt_header:
    .word 0x020B                        /* Magic: PE32+ */
    .byte 0, 1                          /* Linker version */
    .long __text_raw_size               /* SizeOfCode */
    .long 0                             /* SizeOfInitializedData */
    .long 0                             /* SizeOfUninitializedData */
    .long __entry_rva                   /* AddressOfEntryPoint */
    .long __text_rva                    /* BaseOfCode */

    /* Windows / PE32+ specific fields */
    .quad 0                             /* ImageBase (relocatable) */
    .long 0x1000                        /* SectionAlignment */
    .long 0x1000                        /* FileAlignment (matches SectionAlignment) */
    .word 0, 0                          /* OSVersion */
    .word 0, 0                          /* ImageVersion */
    .word 0, 0                          /* SubsystemVersion */
    .long 0                             /* Win32VersionValue */
    .long __image_size                  /* SizeOfImage */
    .long __headers_size                /* SizeOfHeaders */
    .long 0                             /* CheckSum */
    .word 10                            /* Subsystem: EFI Application */
    .word 0                             /* DllCharacteristics */
    .quad 0x100000                      /* SizeOfStackReserve */
    .quad 0x10000                       /* SizeOfStackCommit */
    .quad 0x100000                      /* SizeOfHeapReserve */
    .quad 0x10000                       /* SizeOfHeapCommit */
    .long 0                             /* LoaderFlags */
    .long 16                            /* NumberOfRvaAndSizes */

    /* Data Directories (16 * 8 = 128 bytes) */
    .space 5 * 8                        /* 0..4: Export, Import, Resource, Exception, Security */
    .long __reloc_rva                   /* 5: Base Relocation Table RVA */
    .long __reloc_size                  /* 5: Base Relocation Table Size */
    .space 10 * 8                       /* 6..15 */
opt_header_end:

section_table:
    /* Section 1: .text (covers .text, .rodata, .data, .bss) */
    .ascii ".text\0\0\0"
    .long __text_vsize                  /* VirtualSize */
    .long __text_rva                    /* VirtualAddress */
    .long __text_raw_size               /* SizeOfRawData */
    .long __text_rva                    /* PointerToRawData */
    .long 0, 0
    .word 0, 0
    .long 0xE0000060                    /* CODE | INITIALIZED_DATA | EXECUTE | READ | WRITE */

    /* Section 2: .reloc (empty dummy relocation block for OVMF) */
    .ascii ".reloc\0\0"
    .long __reloc_size                  /* VirtualSize */
    .long __reloc_rva                   /* VirtualAddress */
    .long __reloc_raw_size              /* SizeOfRawData */
    .long __reloc_rva                   /* PointerToRawData */
    .long 0, 0
    .word 0, 0
    .long 0x42000040                    /* INITIALIZED_DATA | DISCARDABLE | READ */

.section .text
.global efi_main
efi_main:
    /* MS x64 ABI -> System V AMD64 ABI */
    pushq %rbx
    pushq %rbp
    pushq %rdi
    pushq %rsi
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15

    movq %rcx, %rdi     /* arg1: ImageHandle */
    movq %rdx, %rsi     /* arg2: SystemTable */
    subq $8, %rsp       /* align stack to 16 bytes before call */
    call kmain
    addq $8, %rsp

    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rsi
    popq %rdi
    popq %rbp
    popq %rbx
    ret

/* void uefi_putc(u64 sys_table, u8 ch) */
.global uefi_putc
uefi_putc:
    /* System V: %rdi = sys_table, %sil = ch */
    pushq %rbp
    movq %rsp, %rbp
    subq $48, %rsp                  /* 32-byte MS shadow space + 16-byte UTF-16 buf */

    movzbl %sil, %eax
    movw %ax, -8(%rbp)              /* CHAR16[0] = ch */
    movw $0, -6(%rbp)               /* CHAR16[1] = 0 (null terminator) */

    movq 64(%rdi), %rcx             /* %rcx = SystemTable->ConOut */
    leaq -8(%rbp), %rdx             /* %rdx = &buf */
    movq 8(%rcx), %rax              /* %rax = ConOut->OutputString */
    call *%rax

    leave
    ret

.section .reloc, "a"
    .long 0
    .long 8
